#import "../utils/context.typ": *
#import "../utils/anchors.typ": *
#import "@preview/cetz:0.5.2"

#let draw-fragment-text(ctx, mol, pos) = {
  import cetz.draw: *
  let id = 0
  let no-anchor-id = 0
  let last-anchor-name = none
  for (eq, anchored) in mol.atoms {
    let name = str(id)
    if not anchored {
      name += str(no-anchor-id)
      no-anchor-id += 1
    }

    let color = if mol.colors != none {
      if type(mol.colors) == color {
        mol.colors
      } else {
        mol.colors.at(calc.min(id, mol.colors.len() - 1))
      }
    } else {
      ctx.config.fragment-color
    }
    let fragment-font = ctx.config.fragment-font

    // draw atoms of the group one after the other from left to right
    content(
      name: name,
      anchor: if mol.vertical {
        "north"
      } else {
        "mid-west"
      },
      (
        if last-anchor-name == none {
          pos
        } else if mol.vertical {
          (to: last-anchor-name + ".south", rel: (0, -.2em))
        } else {
          last-anchor-name + ".mid-east"
        }
      ),
      auto-scale: false,
      {
        show math.equation: math.upright
        set text(fill: color) if color != none
        set text(font: fragment-font) if fragment-font != none
        eq
      },
    )
    if anchored {
      id += 1
    }
    last-anchor-name = name
  }
}

#let draw-fragment-lewis(ctx, group-name, count, lewis) = {
  if lewis.len() == 0 {
    return ()
  }
  import cetz.draw: *
  get-ctx(cetz-ctx => {
    for (id, (angle: lewis-angle, radius, draw)) in lewis.enumerate() {
      if (lewis-angle == none) {
        lewis-angle = ctx.config.lewis.angle
      }
      if (radius == none) {
        radius = ctx.config.lewis.radius
      }
      let lewis-angle = angles.angle-correction(lewis-angle)
      let mol-id = if angles.angle-in-range-inclusive(
        lewis-angle,
        90deg,
        270deg,
      ) {
        0
      } else {
        count - 1
      }
      let anchor = fragment-anchor(
        cetz-ctx,
        lewis-angle,
        group-name,
        str(mol-id),
        radius,
      )
      scope({
        set-origin(anchor)
        rotate(lewis-angle)
        draw(ctx, cetz-ctx)
      })
    }
  })
}

#let draw-fragment-elements(mol, ctx) = {
  let name = mol.name
  if name in ctx.hooks {
    panic("Molecule fragment with name " + name + " already exists : " + ctx
      .hooks
      .keys()
      .join(", "))
  }
  ctx.hooks.insert(name, mol)

  let (group-anchor, side, coord) = if ctx.last-anchor.type == "coord" {
    ("west", true, ctx.last-anchor.anchor)
  } else if ctx.last-anchor.type == "link" {
    if ctx.last-anchor.to == none {
      ctx.last-anchor.to = link-fragment-index(
        ctx.last-anchor.angle,
        true,
        mol.count - 1,
        mol.vertical,
      )
    }
    let group-anchor = link-fragment-anchor(ctx.last-anchor.to, mol.count)
    ctx.last-anchor.to-name = name
    (group-anchor, false, ctx.last-anchor.name + "-end-anchor")
  } else {
    panic("A molecule fragment must be linked to a coord or a link")
  }
  ctx = context_.set-last-anchor(
    ctx,
    (
      type: "fragment",
      name: name,
      count: mol.count,
      vertical: mol.vertical,
      empty: mol.empty,
    ),
  )
  if (side) {
    ctx.id += 1
  }
  (
    ctx,
    {
      import cetz.draw: *
      group(
        anchor: if side {
          group-anchor
        } else {
          "from" + str(ctx.id)
        },
        name: name,
        {
          anchor("default", coord)
          draw-fragment-text(ctx, mol, coord)
          if not side {
            anchor("from" + str(ctx.id), group-anchor)
          }
        },
      )
      draw-fragment-lewis(ctx, name, mol.count, mol.at("lewis"))
    },
  )
}

#let draw-fragment(element, ctx) = {
  if ctx.first-branch {
    panic("A molecule fragment can not be the first element in a cycle")
  }
  let (ctx, drawing) = draw-fragment-elements(element, ctx)
  if element.links.len() != 0 {
    ctx.hooks.insert(ctx.last-anchor.name, element)
    ctx.hooks-links.push((
      element.links,
      ctx.last-anchor.name,
      true,
      element.empty,
    ))
  }
  (ctx, drawing)
}
